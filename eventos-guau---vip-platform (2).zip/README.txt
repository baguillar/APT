
Eventos GUAU - VIP Platform
---------------------------
Senior Full-Stack Solution for Dog Training Management.

INSTALLATION STEPS:
1. Upload all files to your server (Raiola Networks Hosting recommended).
2. RENAMING:
   - Rename all .txt files in the /api folder to .php (e.g., config.txt -> config.php).
   - Rename htaccess.txt to .htaccess in the root.
3. DATABASE:
   - Import database.txt into your MariaDB database.
   - Credentials configured in api/config.php:
     DB: qqxbjuzr_vip | User: qqxbjuzr_soletevip | Pass: Ev3nt0s+Guau
4. REDSYS (Test Mode):
   - Key: sq7HjrUOBfKmC576ILgskD5srU870gJ7
   - Terminal: 002
   - MerchantCode: 368639589

STRICT TECH STACK:
- Frontend: HTML5, CSS3, Vanilla JavaScript (ES6+).
- Backend: PHP 8.x (PDO).
- No TypeScript, No React, No Tailwind.

CREDENTIALS:
Admin: hola@eventosguau.es / admin123
Básico: basico@test.com / guau123
Premium: premium@test.com / guau123
